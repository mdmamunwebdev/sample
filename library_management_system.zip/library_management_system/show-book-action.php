<?php

    include'admin/dbconfig.php';
	
	session_start();
	$session = $_SESSION['user_name'];
	if($session == true)
	{   

        if(isset($_POST['bsearch']))
		{
			$bnumber = $_POST['bnumber'];
				
			$book_q ="select * from book_list where book_number ='$bnumber'";
			$book_connection =mysqli_query($con,$book_q);
			$rows = mysqli_num_rows($book_connection);
			
			
			if(isset($book_connection)){
				
				
				
				
				if($rows > 0){
					
					$_SESSION['book-number'] = $bnumber;
					echo"
					<script>
					
					     
						 window.location.href = 'show-book.php';
					     
					
					</script>
				
					";
					
					
					
				}
				else{
					
					
					echo"
					<script>
					
					     alert('incorrect book-number!!!');
						 window.location.href = 'library_book_info.php';
					
					
					</script>
				
					";
					
					
					
					
				}
				
			
				
				
				
				
				
			}
			else{
				
				
			echo" <script>
			 
			  alert(' unsuccessfully!!');
			  
			 </script>";
					
				
				
				
				
			}
		
			

		
		
		
		
		
		
		
		}
		else{}
    




    }
	else{
		header('location:log-out.php');
		
	}
	
	


?>