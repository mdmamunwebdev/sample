<?php

include'admin/dbconfig.php';
session_start();
$session = $_SESSION['user_name'];
 if($session == true)
 {       }
else{
	header('location:log-out.php');
	
}
?>






<!DOCTYPE HTML><!--  shortcut key html:5 ctrl+E -->
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon" href="image/govt.png" />
	<title>CSE LIBRARY PAGE</title>
	<link rel="stylesheet" href="css/all.css" />
	<link rel="stylesheet" href="css/jquery-ui.min.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="css/main.css" />
	<link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet"> 
</head>
<body onload="myFunction()" style="margin:0;">
                      <!--page loader-->
				<div id="page-loader" style="height:100%; width:100%;top:0px; left:0px; background-color:#52B3E0; z-index:110; position:fixed;">	  
                    <div id="loader"></div>
				</div>
					 <!--  header section -->
					
	<section class="header1" >
	    <div class="container-fluid" style="background-color:green; ">																
			<div class="row" style="background-color: #32353A; padding:0px;" >
								
				<div class="col-md-1">
					<div class="logo"><img style=" background-color:; wight:100%; height:100%; " src="image/govt.png" alt="delta" /></div>	
				</div>
				
				<div class="col-md-11">
												
					<div class="head-line" style="margin-left:500px;"><h1 style=" font-family:Castellar;letter-spacing:2px;<!--/* font-family: 'Great Vibes', cursive;font-family: 'Cookie', cursive;font-family: 'Tangerine', cursive; */-->">CSE LIBRARY</h1></div>

				</div>

			</div>
		</div>	
	</section>
	
	                         <!-- nev and block section  -->
	
	<section class="">
		<div class="container-fluid">		
			<div class="row" style="margin-right:0px;">
			                 
							<!--DASHBOARD BUTTON SECTION--> 
							 
							 
				<div class="col-md-2" style="padding:0px;">
					<div class="side-bar">
					
						<ul>
							<li class="s-list " onclick="currentBlock(1)"><i class="fas fa-home" style="color: #868C90;"></i><h4 class="menu-h4">DASHBOARD</h4></li>
							<li class="s-list " onclick="book_issue()"><i class="fas fa-book" style="color: #868C90;"></i><h4 class="menu-h4">BOOK ISSUE</h4></li>
							<li class="s-list " onclick="student_info()"><i class="fas fa-info" style="color: #868C90;"></i><h4 class="menu-h4">STUDENT INFO</h4></li>
							<li class="s-list " onclick="currentBlock(4)"><i class="fas fa-book-open" style="color: #868C90;"></i><h4 class="menu-h4">LIB-BOOK</h4></li>
							<li onclick="logout()" ><i class="fas fa-sign-out-alt" style="color: #868C90;"></i><h4 class="menu-h4">LOGOUT</h4></li>
						</ul>
						
					</div>
				</div>
				
				
				<div class="col-md-10" style="padding:0px;">
					<div class="block">
					     
						 <div class="main-block">
						 
						      <div class="my-block block-1">
							       <!--<div class="header-b-1"><h1 style="text-align:center; text-transform:uppercase; color: #E7E7E8; font-family:Bookman Old Style;">dashboard of library management system</h1></div>-->
							       <div class="container" style="height:800px; width:100%; background-color:;opacity:0.8;background-image: url('image/scis_bl0417_2_119.jpg');background-size:cover; background-height:100vh;">
								   </br>
										<div class="row" style="margin-top:50px; padding-left:80px;">
										
										<!--HOME PAGE BOOK ISSUE SECTION-->
										
										     <div class="col-md-4">											 
											      <div class="book-issue" onclick="book_issue()">
												       <div class="circle-b-1" style="padding-left:5px;padding-top:0px;">
															<i class="fas fa-book" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Book Issue</h4>
												  </div> 	
											 </div>
											 
										<!--STUDENT INFO SECTION---->	 
										
										     <div class="col-md-4">
											        <div class="s-info" onclick="student_info()">
												       <div class="circle-b-1" style="padding-left:30px;padding-top:0px;">
															<i class="fas fa-info" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Student Info</h4>
													   
												  </div> 
											 </div>
										<!--library SECTION---->	 
											 
											 
										     <div class="col-md-4">
											        <div class="s-phone-number" onclick="library_book_info()">
												       <div class="circle-b-1" style="padding-left:5px;padding-top:0px;">
													        <i class="fas fa-book-open" style="color: #868C90; margin-bottom:20px;"></i>
															
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Library</h4>
												  </div> 
											 </div>
										</div>
										
										
										<div class="row" style="margin-top:100px; padding-left:80px;">
										     <div class="col-md-4">
											      <div class="cse"onclick="currentBlock(4)">
												       <div class="circle-b-1">
													        <i class="fa fa-desktop" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">CSE Department</h4>
												  </div> 	
											 </div>
										     <div class="col-md-4">
											        <div class="bba" onclick="bba_books_info()">
												       <div class="circle-b-1">
													        <i class='fas fa-city' style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">BBA Department</h4>
												  </div> 
											 </div>
										     <div class="col-md-4">
											        <div class="mba" onclick="mba_books_info()">
												       <div class="circle-b-1">
													         <i class='fas fa-graduation-cap' style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">MBA Department</h4>
												  </div> 
											 </div>
										</div>
								   </div>
							  </div>
							  
						      <div class="my-block block-2">

							  </div>
						      <div class="my-block block-3">
							
							  </div>
							  
							  <div class="my-block block-4" style=" height: 800px; overflow:auto; background: #2980B9;  /* fallback for old browsers */background: -webkit-linear-gradient(to right, #FFFFFF, #6DD5FA, #2980B9);  /* Chrome 10-25, Safari 5.1-6 */background: linear-gradient(to right, #FFFFFF, #6DD5FA, #2980B9); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */">
							        	
							        
									
									
                                    
   									<div class="container" style="background-color:; height:; padding:0px;">
									     <h1 style="text-align:center; text-transform:uppercase;color:white; font-style:italic;"><u></u></h1>
									     <div class="row" style="background-color:;   height:; overflow:auto; padding-left: 88px; padding-top:50px; padding-bottom: 50px; margin-right:0px;">
										 
												 <?php
												 
													
												  $sql_table     = "select book_number,book_name,writer,edition,department,date,image from book_list where department ='cse'";
												  $connecttable = mysqli_query($con,$sql_table);
												  
												  $rowstable    = mysqli_num_rows($connecttable); 
												  
												  
												 
												  if(isset($connecttable)){
													  
													  
													while($showtable    = mysqli_fetch_assoc($connecttable)){ 
													
													?>
																			
																			
														<div class="col-md-2 col-book" style="" >
													
														<div class="cover">
													   <?php 
													   if($showtable['image'] == true){
														   echo"<img height='100%' width='100%'  style='background-color:;' src=".$showtable['image']." alt='cover-image' />";
													   }
													   else{
														   
														   echo"<img height='100%' width='100%'   style='background-color:;' src='image/book-cover.png' alt='cover-image' />";
														   
													   }
													   ?>
														</div>
														<div class="book-info" style="">
														
															 <div class="b-e-d-btn">
															   <ul>
																   <li onclick="document.getElementById('id02').style.display='block'" style="display:inline-block; margin-left:20px;" ><a href="#" style = "font-size:10px; "><i style="margin-right:2px;" class="fas fa-trash-alt"></i>Delete</a></li>
																   <li onclick="document.getElementById('id03').style.display='block'" style="display:inline-block;"><a href="#" style ="font-size:10px; "><i style="margin-right:2px;" class="fas fa-pen-fancy"></i>Edit</a></li>
															   </ul>
															</div>
															<div class="book-info-h4">
															
														 <?php echo "   
																		<h4>".$showtable['book_number']."</h4>
																		<h4>".$showtable['book_name']."</h4>
																		<h4>".$showtable['writer']."</h4>
																		<h4>".$showtable['edition']."</h4>
																		<h4>".$showtable['department']."</h4>
																		<h4>".$showtable['date']."</h4>
																		
																		";?>
															</div>
															
														</div>
													
													</div>					
																			
																			
																			
												<?php							
													}
		  
													  
												  }
												  else{
													  
													  
													  
													 echo"
																	  <script type='text/javascript'>
																		
																		alert('query unsuccessful');
																		 
																	  
																	  
																	  </script>
																	  
																	  
																	  ";  

													  
												  }

										 ?>
										 
										 
										 
										 
										 
										 
										 
										    

										 </div>
									</div> 

									
								<div class="search-block">
							       <div style="display:inline-block; margin-right:100px;margin-left:410px; margin-top:px; ">
										   <form action="library_book_info.php" method="post">
												
													<button class="save-btn" style="background-color: rgba(0, 0, 0, 0.0); margin: 5px 0px;" name="edit" ><b>BACK</b></button>

										  </form>
								  </div>
                                  <div class="book-add" style="display:inline-block;">
									
										    <button class="save-btn" onclick="document.getElementById('id01').style.display='block'" style="width:auto; background-color: rgba(0, 0, 0, 0.0); margin: 5px 0px;"><b>ADD</b></button>
											  
											  
											                             <!--popup input form for adding book-->
																		 
											 <div id="id01" class="modal">
  
													  <form class="modal-content animate" action="book_add_action.php" method="post" enctype="multipart/form-data">
													  
														<div class="imgcontainer">
														
														  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
														  
														</div>
														

														<div class="container">
														  <label for="bnumber"><b>Book-Number</b></label>
														  
														  <input type="number" placeholder="" name="bnumber" required>
														  
														  <label for="bname"><b>Book-Name</b></label>
														  <input type="text" placeholder="" name="bname" required>
														  
														  <label for="author"><b>Author</b></label>
														  <input type="text" placeholder="" name="author" required>
														  
														  <label for="edition"><b>Edition</b></label>
														  <input type="text" placeholder="" name="edition" required>
														  					  
														  
														  <label for="department"><b>Department</b></label>
														  <input type="text" placeholder="" name="dept" required>
														  
														  <label for="date"><b>Date</b></label>
														  <input type="date" placeholder="" name="date" required>
														  
														  <label for="image" ><b>Cover Page</b></label>
                                                          <input  type="file"  name="cover_img" value="" />
															
														  <button class="save-btn" type="" name="add">ADD BOOK</button>
														  
														</div>

														<div class="container" style="background-color:">
														
														  <button   type="" name="" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
														  
														</div>
														
													  </form>
													
 
												</div>
												
						        </div>    
						    </div>  
									
									
										
							  </div> 
							  
							  
							  
							  

							  
							  
							  
							  
						 </div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	                                            <!--hidden pop up section-->
	
	<section>
	
	                                            <!--popup input form for data delete-->
												<div id="id02" class="modal">
  
													  <form class="modal-content animate" action="book-delete-action.php" method="post">
														<div class="imgcontainer">
														  <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
														  
														</div>

														<div class="container">
														  <label for="bnumber"><b>Book-Number</b></label>
														  
														 <input type='number' placeholder='Enter book-number' name='bnumber' required>
															
														  <button class="save-btn" type="" name="delete">Delete</button>
														  
														</div>

														<div class="container" style="background-color:#f1f1f1">
														  <button   type="" name="" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Cancel</button>
														  
														</div>
													  </form>
												</div>
	
	
	                                             <!--popup input form for data update-->
	
                                            <div id="id03" class="modal">
  
											  <form class="modal-content animate" action="book-update-action.php" method="post" enctype="multipart/form-data">
											  
												<div class="imgcontainer">
												  <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">&times;</span>
												  
												</div>

												<div class="container">
												  <label for="bnumber"><b>Book-Number</b></label>
												  
												  <input type='number' placeholder='Enter book number' name='bnumber' required>
												  
												  <label for="bname"><b>Book-Name</b></label>
												  <input type="text" placeholder="Enter book Name" name="bname" required>

												  <label for="wname"><b>Writer</b></label>
												  <input type="text" placeholder="Enter Writer Name" name="wname" required>
												  
												  <label for="edition"><b>Edition</b></label>
												  <input type="text" placeholder="Enter Edition" name="edition" required>
												  
												  <label for="department"><b>Department</b></label>
												  <input type="text" placeholder="Enter Department" name="department" required>
												  
												  
												  <label for="date"><b>Date</b></label>
												  <input type="date" placeholder="Enter date" name="date" required>
												  
												  <label for="image" ><b>Cover Page</b></label>
                                                  <input  type="file"  name="cover_img" value="" />
													
												  <button class="save-btn" type="" name="edit_save">Save</button>
												  
												 
												</div>

												<div class="container" style="background-color:">
												  <button type="" onclick="document.getElementById('id03').style.display='none'" class="cancelbtn">Cancel</button>
												  
												</div>

											</div>
											 </form>
											 
	</section>			





	
	                          <!-- footer section  -->
	<section class="footer-section">
		<div class="footer">

					<p style="color: #84848470; display:;   text-align:center;">copyright &copy 2020 Design with by: Md:Abdullah Al Mamun</p>

		</div>
	</section>
	
	
	
	
	
	
	
	 <!-- javascript for slider -->
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

	<!-- javascript for font awsome -->
<script type="text/javascript" src="js/all.js"></script>
                                    <!-- javascript for counter-up -->
<script type="text/javascript" src="js/jquery-1.12.4.min.js.js"></script>                                   
<!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script> -->
<!-- <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script> -->
<script type="text/javascript" src="js/jquery.counterup.min.js"></script>
<script type="text/javascript" src="js/waypoints.min.js"></script>


<script type="text/javascript">


var showindex = 4;
showblock();

function currentBlock(n) 
{
  showblock(showindex = n);
}




function showblock(){
	//var n = showindex;
	var i;
	var block =document.getElementsByClassName("my-block");
	var mainb = document.getElementsByClassName("s-list");
	 
	
	for(i = 0; i < block.length; i++ ){
				
		block[i].style.display = "none";
				
	}
  for (i = 0; i < mainb.length; i++) 
  {
      mainb[i].className = mainb[i].className.replace("active","");
	  
  } 
   
	block[showindex-1].style.display = "block";
    mainb[showindex-1].className = mainb[showindex-1].className += " active";
	
	
	
}
 // $(document).ready(function(){
	// $('#datepicker').datepicker({
		// dateFormat:"yy-mm-dd",
		// changeMonth:true
	// }):
// }); 

</script>
	
<script type="text/javascript">

   function book_issue(){
	   
	   window.location.href="book-issue.php";
	   
   }
   function student_info(){
	   
	   window.location.href="student-info.php";
   }
   function library_book_info(){
	   
	   window.location.href="library_book_info.php";
   }
    function cse_books_info(){
	   
	   window.location.href="cse_books.php";
   }
   function bba_books_info(){
	   
	   window.location.href="bba_books.php";
   }
   function mba_books_info(){
	   
	   window.location.href="mba_books.php";
   }

   function logout(){
	   
	alert('thank tou for log-out!!!');
	window.location.href='log-out.php';
	//document.write("mamun");
	
	
}



</script>

<script>

// Get the modal
var moda = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == moda) {
        moda.style.display = "none";
    }
}
</script>

<script>

// Get the modal
var moda = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == moda) {
        moda.style.display = "none";
    }
}
</script>

<script>

// Get the modal
var moda = document.getElementById('id03');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == moda) {
        moda.style.display = "none";
    }
}
</script>

<script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("page-loader").style.display = "none";
  /* document.getElementById("myDiv").style.display = "block"; */
}
</script>
	
</body>
</html>