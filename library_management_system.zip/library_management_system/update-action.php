<?php

    include'admin/dbconfig.php';                             //database connection
	
	
	if(isset($_POST['edit_save'])){
		
		 $edit_name    = $_POST['name'];
		 $edit_bname   = $_POST['bname'];
		 $edit_bnumber = $_POST['bnumber'];
		 $edit_phone   = $_POST['phone'];
		 $edit_date    = $_POST['date'];
		 $edit_roll    = $_POST['roll'];
		 
		 $edit_image_name        = $_FILES['image']['name'];
		 $temporary_image_name   = $_FILES['image']['tmp_name'];
		 $folder = "student_img/".date('Y-M-D-h-i-s').$edit_image_name;
		 
		 move_uploaded_file($temporary_image_name,$folder);
		 
			$update_q    = "select * from student_info where roll ='$edit_roll'";
			$connectedit = mysqli_query($con,$update_q);
		
		$row =mysqli_num_rows($connectedit);
		
		if($row > 0){
			
			
			if($edit_image_name == true){
			$edit_q      ="update student_info set student_name='$edit_name', book_name ='$edit_bname', book_serial ='$edit_bnumber', phone ='$edit_phone', date ='$edit_date',image ='$folder' where roll='$edit_roll'";
		    $connectedit = mysqli_query($con,$edit_q);
			}
			else{
				
			$edit_q      ="update student_info set student_name='$edit_name', book_name ='$edit_bname', book_serial ='$edit_bnumber', phone ='$edit_phone', date ='$edit_date' where roll='$edit_roll'";
		    $connectedit = mysqli_query($con,$edit_q);
				
			}
		
		
		    if($connectedit){
			
			
		         echo"<script type='text/javascript'>
			
			               alert('Data Updated Successfully  !!');
			               window.location.href ='student-info-show.php';
			
		              </script>";
		  
			
		    }
		    else{
			
		         echo" <script type='text/javascript'>
			
			              alert('oops!! Data Updated Unsuccessfully  !!');
						  window.location.href ='student-info-show.php';
			
		              </script>";
		  
		    }
			
		}
		else{
			
			echo" <script type='text/javascript'>
			
			            alert('OOPS !! Please Enter Correct Roll  !!');
						window.location.href ='student-info.php';
			
		         </script>";
				
		}

	}
	else{
		
		//this filed for first if condition
		
		echo" <script type='text/javascript'>
	
				    window.location.href ='student-info.php';
			
		       </script>";

	}

  ?>