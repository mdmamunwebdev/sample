<?php

$host= "localhost";
$user= "root";
$pass= "";
$db= 'library-management-system';

$con=mysqli_connect($host,$user,$pass) or die('database error!!');
	mysqli_select_db($con,$db);
	mysqli_set_charset($con, "utf8");

?>


<?php



/* class Database {
    private $dbhost, $dbuser, $dbname, $lik;
	private $dbpass ="";

    public function __construct($host,$user,$name){
        $this->dbhost = $host;
        $this->dbuser = $user;
        
        $this->dbname   = $name;
    }   

    public function Connect (){
       
	  $link = mysqli_connect ($this->dbhost,$this->dbuser,$this->dbpass,$this->dbname)
            OR die (mysqli_error());
	  $this->lik =$link;
    }


    public function SetNamesUTF8($unicode){
        mysqli_set_charset($this->lik, $unicode);
    }
}

$Database = new Database('localhost','root','library-management-system');
$Database -> Connect(); 
$Database -> SetNamesUTF8('UTF8');


 */


?>


<?php
//$link = mysqli_connect('localhost', 'root', '', 'library-management-system');

//check connection
//if (mysqli_connect_errno()) {
   // printf("Connect failed: %s\n", mysqli_connect_error());
   // exit();
//}

//printf("Initial character set: %s\n", mysqli_character_set_name($link));
  // mysqli_character_set_name($link);

//change character set to utf8
//if (!mysqli_set_charset($link, "utf8")) {
    //printf("Error loading character set utf8: %s\n", mysqli_error($link));
   // exit();
//}  else{
    /* printf("Current character set: %s\n", mysqli_character_set_name($link));
	mysqli_character_set_name($link);
	
} */ 

/* mysqli_close($link); */
?>




