<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php
    
	include'admin/dbconfig.php';
	
	session_start();
	$session = $_SESSION['user_name'];
	 if($session == true)
	 {       }
	else{
		header('location:log-out.php');
		
	}
	
	
	if(isset($_POST['add'])){
	   
	   $bnumber  = $_POST['bnumber'];
	   $bname  = $_POST['bname'];
	   $author = $_POST['author'];
	   $edition  = $_POST['edition'];
	   $dept  = $_POST['dept'];
	   $date   = $_POST['date'];
	   
	   
	   $img_name      = $_FILES['cover_img']['name'];
	   $temprary_name = $_FILES['cover_img']['tmp_name'];
	   $folder ="student_img/".date('Y-M-D-h-i-s').$img_name;
	   
	  /*  this function is used to move image from temporary storage to database folder */
	   
	   move_uploaded_file($temprary_name,$folder);
	   
	   /* $s = "insert into user(username,email,password,code) values('$sname','$sroll','$date','$bname')";	   
	   $quary_chack=mysqli_query($con,$s); */
	   
	   if($img_name == true){
	   $q = "insert into book_list(book_number,book_name,writer,edition,department,date,image) values('$bnumber','$bname','$author','$edition','$dept','$date','$folder')";	   
	   $quary_chack=mysqli_query($con,$q);
	  
	   }
	   
	   else{
	   $q = "insert into book_list(book_number,book_name,writer,edition,department,date) values('$bnumber','$bname','$author','$edition','$dept','$date')";	   
	   $quary_chack=mysqli_query($con,$q);
	  
	   }
	   
	   
	   
	   
	   if($quary_chack){
		  

           
			echo" <script>
			 
			  alert('data insert successfully!!');
			  window.location.href='library_book_info.php';
			 </script>";
					 
			
	    

		  
	   }
	   else{
		   
		   
		   
					echo" <script>
					 
					 alert('data insert not successfully!!');
					  window.location.href='library_book_info.php';
					 </script>
					 
					 ";
		   
		   
		   
	   }
	 
	   
	   
	   
   }
   else{
	   
	   
	      echo"
					 <script>
					 
					 window.location.href='library_book_info.php';
					 
					 </script>
					 
					 ";
	    
	   
	   
	   
   }
	
	



?>
</body>
</html>



