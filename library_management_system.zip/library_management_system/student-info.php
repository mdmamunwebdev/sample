<?php

include'admin/dbconfig.php';
session_start();
$session = $_SESSION['user_name'];
 if($session == true)
 {       }
else{
	header('location:log-out.php');
	
}
?>






<!DOCTYPE HTML><!--  shortcut key html:5 ctrl+E -->
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon" href="image/govt.png" />
	<title>STUDENT INFO PAGE</title>
	<link rel="stylesheet" href="css/all.css" />
	<link rel="stylesheet" href="css/jquery-ui.min.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="css/main.css" />
	<link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet"> 
</head>
<body>
                    
					 <!--  header section -->
					
	<section class="header1" >
	    <div class="container-fluid" style="background-color:green; ">																
			<div class="row" style="background-color: #32353A; padding:0px;" >
								
				<div class="col-md-1">
					<div class="logo"><img style=" background-color:; wight:100%; height:100%; " src="image/govt.png" alt="delta" /></div>	
				</div>
				
				<div class="col-md-11">
												
					<div class="head-line"><h1 style=" font-family:Castellar;letter-spacing:2px;<!--/* font-family: 'Great Vibes', cursive;font-family: 'Cookie', cursive;font-family: 'Tangerine', cursive; */-->">delta computer science college</h1></div>

				</div>

			</div>
		</div>	
	</section>
	
	                         <!-- nev and block section  -->
	
	<section class="">
		<div class="container-fluid">		
			<div class="row">
			                 
							<!--DASHBOARD BUTTON SECTION--> 
							 
							 
				<div class="col-md-2" style="padding:0px;">
					<div class="side-bar">
					
						<ul>
							<li class="s-list " onclick="currentBlock(1)"><i class="fas fa-home" style="color: #868C90;"></i><h4 class="menu-h4">DASHBOARD</h4></li>
							<li class="s-list " onclick="book_issue()"><i class="fas fa-book" style="color: #868C90;"></i><h4 class="menu-h4">BOOK ISSUE</h4></li>
							<li class="s-list " onclick="currentBlock(3)"><i class="fas fa-info" style="color: #868C90;"></i><h4 class="menu-h4">STUDENT INFO</h4></li>
							<li class="s-list " onclick="library_book_info()"><i class="fas fa-book-open" style="color: #868C90;"></i><h4 class="menu-h4">LIB-BOOK</h4></li>
							<li onclick="logout()" ><i class="fas fa-sign-out-alt" style="color: #868C90;"></i><h4 class="menu-h4">LOGOUT</h4></li>
						</ul>
						
					</div>
				</div>
				
				
				<div class="col-md-10" style="padding:0px;">
					<div class="block">
					     <!--<div class="search-block"></div>-->
						 <div class="main-block">
						 
						      <div class="my-block block-1">
							       <!--<div class="header-b-1"><h1 style="text-align:center; text-transform:uppercase; color: #E7E7E8; font-family:Bookman Old Style;">dashboard of library management system</h1></div>-->
							       <div class="container" style="height:800px; width:100%; background-color:;opacity:0.8;background-image: url('image/scis_bl0417_2_119.jpg');background-size:cover; background-height:100vh;">
								   </br>
										<div class="row" style="margin-top:50px; padding-left:80px;">
										
										<!--HOME PAGE BOOK ISSUE SECTION-->
										
										     <div class="col-md-4">											 
											      <div class="book-issue" onclick="book_issue()">
												       <div class="circle-b-1" style="padding-left:5px;padding-top:0px;">
															<i class="fas fa-book" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Book Issue</h4>
												  </div> 	
											 </div>
											 
										<!--STUDENT INFO SECTION---->	 
										
										     <div class="col-md-4">
											        <div class="s-info" onclick="currentBlock(3)">
												       <div class="circle-b-1" style="padding-left:30px;padding-top:0px;">
															<i class="fas fa-info" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Student Info</h4>
													   
												  </div> 
											 </div>
											 
										<!--library SECTION---->	 
											 
											 
										     <div class="col-md-4">
											        <div class="s-phone-number" onclick="library_book_info()">
												       <div class="circle-b-1" style="padding-left:5px;padding-top:0px;">
													        <i class="fas fa-book-open" style="color: #868C90; margin-bottom:20px;"></i>
															
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Library</h4>
												  </div> 
											 </div>
										</div>
										
										
										<div class="row" style="margin-top:100px; padding-left:80px;">
										     <div class="col-md-4">
											      <div class="cse" onclick="cse_books_info()">
												       <div class="circle-b-1">
													        <i class="fa fa-desktop" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">CSE Department</h4>
												  </div> 	
											 </div>
										     <div class="col-md-4">
											        <div class="bba" onclick="bba_books_info()">
												       <div class="circle-b-1">
													        <i class='fas fa-city' style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">BBA Department</h4>
												  </div> 
											 </div>
										     <div class="col-md-4">
											        <div class="mba" onclick="mba_books_info()">
												       <div class="circle-b-1">
													         <i class='fas fa-graduation-cap' style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">MBA Department</h4>
												  </div> 
											 </div>
										</div>
								   </div>
							  </div>
							  
							  
							  
						      <div class="my-block block-2">
                                  
								  
							  </div>
							  
							  
							  
						      <div class="my-block block-3" style="background-image: url('image/photo-1497633762265-9d179a990aa6.jpg');background-size: cover;padding-top: 330px;opacity: 0.8" >


															<!--search box for books-->
								<div class="sinfo-search-block">
									<div class="second-search-block">
										<form method="post" action="student-info-action.php">
                                          <span id = "search-icon"><img id="icon-img" src="image/govt.png" alt="" /></span>										
										  <input type="text" id="book-search" name="roll" placeholder="please enter roll number...." required />
										  <button id="search-btn" name="search"><i class="fas fa-arrow-right"></i></button>
										</form> 
									</div>
								</div>


								
							  </div>
						 </div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	                          <!-- footer section  -->
	<section class="footer-section">
		<div class="footer">

					<p style="color: #84848470; display:;   text-align:center;">copyright &copy 2020 Design with by: Md:Abdullah Al Mamun</p>

		</div>
	</section>
	
	
	
	
	
	
	
	 <!-- javascript for slider -->
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

	<!-- javascript for font awsome -->
<script type="text/javascript" src="js/all.js"></script>



<script type="text/javascript">


var showindex = 3;
showblock();

function currentBlock(n) 
{
  showblock(showindex = n);
}




function showblock(){
	//var n = showindex;
	var i;
	var block =document.getElementsByClassName("my-block");
	var mainb = document.getElementsByClassName("s-list");
	 
	
	for(i = 0; i < block.length; i++ ){
				
		block[i].style.display = "none";
				
	}
  for (i = 0; i < mainb.length; i++) 
  {
      mainb[i].className = mainb[i].className.replace("active","");
	  
  } 
   
	block[showindex-1].style.display = "block";
    mainb[showindex-1].className = mainb[showindex-1].className += " active";
	
	
	
}
 // $(document).ready(function(){
	// $('#datepicker').datepicker({
		// dateFormat:"yy-mm-dd",
		// changeMonth:true
	// }):
// }); 

</script>
	
<script type="text/javascript">

   function book_issue(){
	   
	   window.location.href="book-issue.php";
	   
   }
   function student_info(){
	   
	   window.location.href="student-info.php";
   }
   
   function library_book_info(){
	   
	   window.location.href="library_book_info.php";
   }
   
   function cse_books_info(){
	   
	   window.location.href="cse_books.php";
   }
   function bba_books_info(){
	   
	   window.location.href="bba_books.php";
   }
   function mba_books_info(){
	   
	   window.location.href="mba_books.php";
   }

   function logout(){
	   
	alert('thank tou for log-out!!!');
	window.location.href='log-out.php';
	//document.write("mamun");
	
	
}



</script>
	
</body>
</html>