<?php

    include'admin/dbconfig.php';                             //database connection
	
	
	if(isset($_POST['edit_save'])){
		
		 $bnumber          = $_POST['bnumber'];
		 $edit_bname       = $_POST['bname'];
		 $edit_wname       = $_POST['wname'];
		 $edit_edition     = $_POST['edition'];
		 $edit_department  = $_POST['department'];
		 $edit_date        = $_POST['date'];
		 
		 $image_name=$_FILES['cover_img']['name'];
		 $temporary=$_FILES['cover_img']['tmp_name'];
		 $folder ="student_img/".date('Y-M-D-h-i-s').$image_name;
	   
	     /*  this function is used to move image from temporary storage to database folder */
	   
	     move_uploaded_file($temporary,$folder);
		
		$update_q    = "select * from book_list where book_number ='$bnumber'";
		$connectedit = mysqli_query($con,$update_q);
		
		$row =mysqli_num_rows($connectedit);
		
		if($row > 0){
			
			
			if($image_name == true){
			$edit_q      ="update book_list set book_name='$edit_bname', writer ='$edit_wname', edition ='$edit_edition', department ='$edit_department' , date ='$edit_date',image ='$folder' where book_number='$bnumber'";
		    $connectedit = mysqli_query($con,$edit_q);
			}
			else{
			$edit_q      ="update book_list set book_name='$edit_bname', writer ='$edit_wname', edition ='$edit_edition', department ='$edit_department' , date ='$edit_date' where book_number='$bnumber'";
		    $connectedit = mysqli_query($con,$edit_q);
			}
		
		    if($connectedit){
			
			
		         echo"<script type='text/javascript'>
			
			               alert('Data Updated Successfully  !!');
			               window.location.href ='show-book.php';
			
		              </script>";
		  
			
		    }
		    else{
			
		         echo" <script type='text/javascript'>
			
			              alert('oops!! Data Updated Unsuccessfully  !!');
						  window.location.href ='show-book.php';
			
		              </script>";
		  
		    }
			
		}
		else{
			
			echo" <script type='text/javascript'>
			
			            alert('OOPS !! Please Enter Correct Roll  !!');
						window.location.href ='show-book.php';
			
		         </script>";
				
		}

	}
	else{
		
		//this failed for first if condition
		
		echo" <script type='text/javascript'>
	
				    window.location.href ='show-book.php';
			
		       </script>";

	}

  ?>