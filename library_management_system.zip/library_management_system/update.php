<?php

include'admin/dbconfig.php';
session_start();
$session = $_SESSION['user_name'];
 if($session == true)
 {       }
else{
	header('location:log-out.php');
	
}
?>




<!DOCTYPE HTML><!--  shortcut key html:5 ctrl+E -->
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon" href="image/govt.png" />
	<title>BOOK ISSUE PAGE</title>
	<link rel="stylesheet" href="css/all.css" />
	<link rel="stylesheet" href="css/jquery-ui.min.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="css/main.css" />
	<link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet"> 
</head>
<body>
                    
					 <!--  header section -->
					
	<section class="header1" >
	    <div class="container-fluid" style="background-color:green; ">																
			<div class="row" style="background-color: #32353A; padding:0px;" >
								
				<div class="col-md-1">
					<div class="logo"><img style=" background-color:; wight:100%; height:100%; " src="image/govt.png" alt="delta" /></div>	
				</div>
				
				<div class="col-md-11">
												
					<div class="head-line"><marquee direction=left><h1 style=" font-family:Castellar;letter-spacing:2px;<!--/* font-family: 'Great Vibes', cursive;font-family: 'Cookie', cursive;font-family: 'Tangerine', cursive; */-->">delta computer science college</h1></marquee></div>

				</div>

			</div>
		</div>	
	</section>
	
	                         <!-- nev and block section  -->
	
	<section class="">
		<div class="container-fluid">		
			<div class="row">
			
				<div class="col-md-2" style="padding:0px;">
					<div class="side-bar">
					
						<ul>
							<li class="s-list " onclick="currentBlock(1)"><i class="fas fa-home" style="color: #868C90;"></i><h4 class="menu-h4">DASHBOARD</h4></li>
							<li class="s-list " onclick="currentBlock(2)"><i class="fas fa-book" style="color: #868C90;"></i><h4 class="menu-h4">BOOK ISSUE</h4></li>
							<li class="s-list " onclick="student_info()"><i class="fas fa-info" style="color: #868C90;"></i><h4 class="menu-h4">STUDENT INFO</h4></li>
							<li onclick="logout()" ><i class="fas fa-sign-out-alt" style="color: #868C90;"></i><h4 class="menu-h4">LOGOUT</h4></li>
						</ul>
						
					</div>
				</div>
				
				
				<div class="col-md-10" style="padding:0px;">
					<div class="block">
					     <div class="search-block"></div>
						 <div class="main-block">
						 
						      <div class="my-block block-1">
							       <!--<div class="header-b-1"><h1 style="text-align:center; text-transform:uppercase; color: #E7E7E8; font-family:Bookman Old Style;">dashboard of library management system</h1></div>-->
							       <div class="container" style="height:740px; width:100%; background-color:white; opacity:0.6;">
								   </br>
										<div class="row" style="margin-top:50px; padding-left:80px;">
										     <div class="col-md-4">
											      <div class="book-issue" onclick="currentBlock(2)">
												       <div class="circle-b-1" style="padding-left:5px;padding-top:0px;">
															<i class="fas fa-book" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Book Issue</h4>
												  </div> 	
											 </div>
										     <div class="col-md-4">
											        <div class="s-info" onclick="student_info()">
												       <div class="circle-b-1" style="padding-left:30px;padding-top:0px;">
															<i class="fas fa-info" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">Student Info</h4>
													   
												  </div> 
											 </div>
										     <div class="col-md-4">
											        <div class="s-phone-number">
												       <div class="circle-b-1" style="padding-left:5px;padding-top:0px;">
															<i class="fas fa-info" style="color: #868C90; margin-bottom:20px;"></i>
													   </div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">S-Phone Number</h4>
												  </div> 
											 </div>
										</div>
										<div class="row" style="margin-top:100px; padding-left:80px;">
										     <div class="col-md-4">
											      <div class="cse">
												       <div class="circle-b-1"></div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">CSE Department</h4>
												  </div> 	
											 </div>
										     <div class="col-md-4">
											        <div class="bba">
												       <div class="circle-b-1"></div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">BBA Department</h4>
												  </div> 
											 </div>
										     <div class="col-md-4">
											        <div class="mba">
												       <div class="circle-b-1"></div>
													   <h4 style="margin-top:156px; margin-left:3px; text-align:center; color: #E7E7E8; background-color:#666A71; font-size:20px; padding:5px 10px; display:inline-block; width:194px; height:40px; ">MBA Department</h4>
												  </div> 
											 </div>
										</div>
								   </div>
							  </div>
							  
						      <div class="my-block block-2">
									<div class="container-fluid">
										<div class="row">
											<div class="col-md-6" style="max-width: 40%; background-color:; height:740px; border-right:2px solid #C8C9CA; ">
												<div class="s-input-form" style="margin-top:50px;">
												
													<form  style="width:450px;" action="action.php" method="post" enctype="multipart/form-data" >
													
													
														<label id="label-form" style="margin-left: 80px;"  >NAME :</label>
														<input id="input-form" type="text" name="name"  placeholder="   ex:  mamun" required />
														
														</br>
														<label id="label-form" style="margin-left:87px;"   >ROLL :</label>
														<input id="input-form" type="text" name="roll" placeholder="   ex:  " required />
														
														</br>
														<label id="label-form" style="margin-left:68px;" >PHONE :</label>
														<input id="input-form" type="number" name="phone-number" placeholder="   ex:  017......." required />
														
														</br>
														<label id="label-form" style="margin-left:29px;" >BOOK NAME :</label>
														<input id="input-form" type="text" name="book-name" placeholder="   ex:  java" required />
														
														</br>
														<label id="label-form"  style="margin-left:20px;">DEPARTMENT :</label>
														<input id="radio-form" type="radio"  name="department" value="CSE" checked="checked" required /><span  id="span-form">CSE .</span>
														<input id="radio-form" type="radio" name="department" value="BBA" required /><span id="span-form">BBA .</span>
														<input id="radio-form" type="radio" name="department" value="MBA" required /><span style="margin-right:100px;" id="span-form">MBA .</span>
														
														
													    <label id="label-form" style="margin-left:14px;" >DATE OF ISSUE :</label>													    
														<input id="input-form" type="date"  name="date-of-issue" placeholder="   ex:  mm/dd/yy" required />
														
														</br>
														<label id="label-form" >student image :</label>
                                                        <input  type="file"  name="image" value=""/>
														</br>
														<input id="save-btn" type="submit" name="save" value="SAVE"/>
														<input id="clear-btn" type="reset" name="clear" value="CLEAR"/>
													</form>
								
												</div>
											</div>
										<div class="col-md-6" style="max-width:60%;">
											
												
													<div class="table-container" style="background-color:green;">
													      <?php
													
													      $sql_table     = "select student_name,roll,phone,book_name,department from student_info";
														  $connecttable = mysqli_query($con,$sql_table);
														  $rowstable    = mysqli_num_rows($connecttable);
														  
														  
														  
														  if(isset($connecttable)){
															  
                                                            if($rowstable != 0){
																
																?>
																<table>
																	<thead>
																		<tr>
																			<th><u>ROLL</u></th>
																			<th><u>NAME</u></th>
																			<th><u>PHONE</u></th>
																			<th><u>BOOK NAME</u></th>
																			<th><u>DEPARTMENT</u></th>
																		</tr>
																	</thead>
																
																<?php
																
																
																
																
																while($showtable    = mysqli_fetch_assoc($connecttable)){
																	
																	echo"
																	
																	   <tbody>
																			<tr>
																				<td>".$showtable['student_name']."</td>
																				<td>".$showtable['roll']."</td>
																				<td>".$showtable['phone']."</td>
																				<td>".$showtable['book_name']."</td>
																				<td>".$showtable['department']."</td>
																			</tr>
																	
																	    </tbody>
																	   
																	";
																	
																	
																	
																	
																	
																}
																
															
															}   
															else{
																 
																 echo "<h1 style='color:green; text-align:center; text-transform:uppercase;'>has no record in database!!</h1>";
																 
															}
															  
															  
														  }
														  else{
															   echo"
															  <script type='text/javascript'>
															    
															    alert('query unsuccessful');
															     
															  
															  
															  </script>
															  
															  
															  ";
														  }
														  
													
													
													    ?>
														
															
															
														</table>
													</div>
												   <form action="update.php" method="post">
                                                   <button class="edit_btn" name="edit" >Edit This Table</button>
												   </form>
											       
										</div>
									    </div>
								</div>
							 </div>
						      <div class="my-block block-3"></div>
						 </div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	                          <!-- footer section  -->
	<section class="footer-section">
		<div class="footer"></div>
	</section>
	                           <!--php section-->
							   
			   
							   
							   

	
	 <!-- javascript for slider -->
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

	<!-- javascript for font awsome -->
<script type="text/javascript" src="js/all.js"></script>



<script type="text/javascript">


var showindex = 2;
showblock();

function currentBlock(n) 
{
  showblock(showindex = n);
}




function showblock(){
	//var n = showindex;
	var i;
	var block =document.getElementsByClassName("my-block");
	var mainb = document.getElementsByClassName("s-list");
	 
	
	for(i = 0; i < block.length; i++ ){
				
		block[i].style.display = "none";
				
	}
  for (i = 0; i < mainb.length; i++) 
  {
      mainb[i].className = mainb[i].className.replace("active","");
	  
  } 
   
	block[showindex-1].style.display = "block";
    mainb[showindex-1].className = mainb[showindex-1].className += " active";
	
	
	
}
 // $(document).ready(function(){
	// $('#datepicker').datepicker({
		// dateFormat:"yy-mm-dd",
		// changeMonth:true
	// }):
// }); 

</script>	
<script type="text/javascript">

   function book_issue(){
	   
	   window.location.href="book-issue.php";
	   
   }
   function student_info(){
	   
	   window.location.href="student-info.php";
   }

   function logout(){
	   
	alert('thank tou for log-out!!!');
	window.location.href='log-out.php';
	//document.write("mamun");
	
	
}



</script>
	
</body>
</html>