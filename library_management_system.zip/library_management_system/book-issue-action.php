<?php
    include 'admin/dbconfig.php';
   if(isset($_POST['save'])){
	   
	   $sname  = $_POST['name'];
	   $sroll  = $_POST['roll'];
	   $sphone = $_POST['phone-number'];
	   $bname  = $_POST['book-name'];
	   $bnumber  = $_POST['bnumber'];
	   $sdept  = $_POST['department'];
	   $date   = $_POST['date-of-issue'];
	   
	   $img_name = $_FILES['image']['name'];
	   $temprary_name = $_FILES['image']['tmp_name'];
	   $folder ="student_img/".date('Y-M-D-h-i-s').$img_name;
	   
	   
	   move_uploaded_file($temprary_name,$folder);  //bug
	   
	   /* $s = "insert into user(username,email,password,code) values('$sname','$sroll','$date','$bname')";	   
	   $quary_chack=mysqli_query($con,$s); */
	   
	   
	   if($img_name == true){
		   
	   $q = "insert into student_info(student_name, roll, phone, book_name, book_serial, department, date, image) values('$sname','$sroll','$sphone','$bname','$bnumber','$sdept','$date','$folder')";	   
	   $quary_chack=mysqli_query($con,$q);
	   }
	   
	   else{
		   
	   $q = "insert into student_info(student_name,roll,phone,book_name,book_serial,department,date) values('$sname','$sroll','$sphone','$bname','$bnumber','$sdept','$date')";	   
	   $quary_chack=mysqli_query($con,$q);
	   }
	   
	   
	   
	   
	   if($quary_chack){
		  

           
			echo" <script>
			 
			  alert('data insert successfully!!');
			  window.location.href='book-issue.php';
			 </script>";
					 
			
	    

		  
	   }
	   else{
		   
		   
		   
					echo" <script>
					 
					 alert('data insert not successfully!!');
					 window.location.href = window.location.book-issue.php;
					 </script>
					 
					 ";
		   
		   
		   
	   }
	 
	   
	   
	   
   }
   else{
	   
	   
	    /*  echo"
					 <script>
					 
					 alert('post sucseccfull!!');
					 
					 </script>
					 
					 ";
	    */
	   
	   
	   
   }
//header('location:book-issue.php');
?>				