<?php

	 include 'admin/dbconfig.php';
     session_start();
	 $session = $_SESSION['user_name'];
	 
	if($session == true)
	{   
		

        	if(isset($_POST['search']))
			{
		 
			 $sroll         = $_POST['roll'];
			 
			 $search_q      ="SELECT * FROM student_info WHERE roll='$sroll' ";
			 $connectsearch = mysqli_query($con,$search_q);
			 /* $showtable    = mysqli_fetch_assoc($connectsearch); */
			 $rows          = mysqli_num_rows($connectsearch);
	
		 
					if(isset($connectsearch))
					{
						
								if($rows > 0)
								{
									
									$_SESSION['student_roll'] = $sroll;
									
									   echo"
											  <script type='text/javascript'>
												
												
												window.location.href ='student-info-show.php';
												
											  </script>
											  
											  "; 
									
									
								}
								else
								{
									
									
									   //header(Location:student-info.php);
										   echo"
												  <script type='text/javascript'>
													
													alert('roll incorrect!!');
													window.location.href ='student-info.php';
													
												  </script>
												  
												  "; 
									
									
									
									
								}
					   
			
			
					}
					else
					{
			 
			 
			 
					   echo"
						  <script type='text/javascript'>
							
							alert('connection_failed!!!');
							window.location.href ='student-info.php';
							
						  </script>
						  
						  "; 
			 
					 //header(Location:student-info.php);
		
			 
			 
			 
					}
	        }
			
			else
			{
				 
				 echo"
							  <script type='text/javascript'>
								
								
								window.location.href ='student-info.php';
								
							  </script>
							  
							  "; 
				 
				 
			}

		
		
		
		
		
		
		
		

	}
	else
	{
		header('location:log-out.php');
		
	}
	 
	 
	 

									 
?>