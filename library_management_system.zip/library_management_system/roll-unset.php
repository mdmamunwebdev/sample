<?php
session_start();


unset($_SESSION['student_roll']);



echo"<script>

window.location.href='student-info.php';


</script>";









?>