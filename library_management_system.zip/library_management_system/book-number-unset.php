<?php
session_start();

unset($_SESSION['book-number']);




echo"<script>

window.location.href='library_book_info.php';


</script>";









?>