<?php
    
	include'admin/dbconfig.php';                                         //database connection
	
	if(isset($_POST['delete'])){
		
		$sroll =$_POST['roll'];
		
		$delete_one_q      = "select * from student_info where roll ='$sroll'";
		$connection_delete = mysqli_query($con,$delete_one_q);
		$delete_row        = mysqli_num_rows($connection_delete);
        $delete_show       = mysqli_fetch_assoc($connection_delete);
        $delete_img        = $delete_show['image'];		
          
        if($delete_row > 0){
			
			$delete_two_q      = "delete from student_info where roll ='$sroll'";
			$connection_delete = mysqli_query($con,$delete_two_q);
			
			if($connection_delete){
				
				unlink($delete_img);
				
				
				echo"<script type='text/javascript'>
			
						alert('Data Deleted Successfully  !!');
						window.location.href ='student-info.php';
						
					 </script>";
				
				
			}
			else{
				
				echo"<script type='text/javascript'>
			
						alert('Data Deleted Unsuccessfully  !!');
						window.location.href ='student-info.php';
						
					 </script>";
				
				
			}

        }
        else{
			
			echo"<script type='text/javascript'>
			
						alert('OOPS !! Please Enter Correct Roll   !!');
						window.location.href ='student-info.php';
						
				</script>";
			
			
		}		

	}
	
	else{
		
		//this filed for first if condition
		
		
		echo" <script type='text/javascript'>
	
				    window.location.href ='student-info.php';
			
		       </script>";
		
		
	}
								
?>