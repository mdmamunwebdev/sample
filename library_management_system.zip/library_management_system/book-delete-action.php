<?php
    
	include'admin/dbconfig.php';                                         //database connection
	
	if(isset($_POST['delete'])){
		
		$bnumber =$_POST['bnumber'];
		
		$delete_one_q      = "select * from book_list where book_number ='$bnumber'";
		$connection_delete = mysqli_query($con,$delete_one_q);
		$delete_row        = mysqli_num_rows($connection_delete);
		
        $delete_show       = mysqli_fetch_assoc($connection_delete);
        $delete_img        = $delete_show['image'];		
          
        if($delete_row > 0){
			
			$delete_two_q      = "delete from book_list where book_number ='$bnumber'";
			$connection_delete = mysqli_query($con,$delete_two_q);
			
			if($connection_delete){
				
				unlink($delete_img);
				
				
				echo"<script type='text/javascript'>
			
						alert('Data Deleted Successfully  !!');
						window.location.href ='library_book_info.php';
						
					 </script>";
				
				
			}
			else{
				
				echo"<script type='text/javascript'>
			
						alert('Data Deleted Unsuccessfully  !!');
						window.location.href ='library_book_info.php';
						
					 </script>";
				
				
			}

        }
        else{
			
			echo"<script type='text/javascript'>
			
						alert('OOPS !! Please Enter Correct Roll   !!');
						window.location.href ='library_book_info.php';
						
				</script>";
			
			
		}		

	}
	
	else{
		
		//this failed for first if condition
		
		
		echo" <script type='text/javascript'>
	
				    window.location.href ='library_book_info.php';
			
		       </script>";
		
		
	}
								
?>